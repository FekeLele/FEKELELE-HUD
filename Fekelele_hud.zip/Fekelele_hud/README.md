# :open_file_folder: FEKELELE HUD

:video_game: **Un HUD moderno, reattivo e animato per il tuo server FiveM!**

Visualizza fame, sete, salute, armatura, stress, microfono dinamico, velocità, carburante e altro.
Creato con attenzione ai dettagli e ottimizzato per prestazioni fluide.

---

## :package: Dipendenze necessarie:

* `es_extended`
* `ox_lib`
* `pma-voice`
* `esx_status`
* `esx_basicneeds`
* `ox_fuel`

---

## :gear: Installazione

1. Scarica la risorsa e inseriscila nella cartella `resources` del tuo server
2. Assicurati di avere tutte le dipendenze installate e funzionanti
3. Aggiungi `start Fekelele_hud` al tuo `server.cfg`
4. Riavvia il server

---

## :sparkles: Caratteristiche

- **HUD Moderno**: Design pulito e professionale
- **Completamente Reattivo**: Si adatta perfettamente a qualsiasi risoluzione
- **Animazioni Fluide**: Transizioni e animazioni ottimizzate
- **Indicatori Multipli**: Fame, sete, salute, armatura, stress
- **Microfono Dinamico**: Integrazione con pma-voice
- **Velocità e Carburante**: Informazioni veicolo in tempo reale
- **Prestazioni Ottimizzate**: Codice ottimizzato per performance elevate

---

## :computer: Compatibilità

- **Framework**: ESX
- **Versione FiveM**: Ultima versione stabile
- **Dipendenze Voice**: pma-voice
- **Sistema Carburante**: ox_fuel

---

## :handshake: Supporto

:wrench: **Per supporto o info apri un ticket su** `#🎫・ticket`

### :link: Collegamenti Utili

- **Discord Server**: [https://discord.gg/VnANeHYP](https://discord.gg/VnANeHYP)
- **Supporto Tecnico**: Disponibile tramite ticket Discord

---

## :busts_in_silhouette: Team di Sviluppo

:computer: **Front-end (CSS/HTML)** → *Mr.Psycho*  
:brain: **Back-end (Lua/JS)** → *Fekelele*

---

## :page_facing_up: Licenza

Questo progetto è sviluppato dal team Fekelele. Tutti i diritti riservati.

---

## :warning: Note Importanti

- Assicurati di configurare correttamente tutte le dipendenze
- Verifica la compatibilità con altri HUD prima dell'installazione
- Per problemi specifici, contatta il team di supporto tramite Discord

---

**Versione**: 1.0.0  
**Autore**: Fekelele  
**Ultimo Aggiornamento**: Luglio 2025

---

*Grazie per aver scelto FEKELELE HUD per il tuo server FiveM! :heart:*
