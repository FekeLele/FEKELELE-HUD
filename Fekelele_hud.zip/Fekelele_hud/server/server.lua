local ESX = exports['es_extended']:getSharedObject()
local playerHudStatus = {}

local function getTranslation(key)
    return Config.getTranslation(key)
end

AddEventHandler('playerDropped', function()
    local src = source
    TriggerClientEvent('hud:requestStatus', src)
end)

RegisterNetEvent('hud:sendStatus')
AddEventHandler('hud:sendStatus', function(status)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    playerHudStatus[src] = status
    if xPlayer then
        TriggerClientEvent('esx:showNotification', src, getTranslation('status_hud_saved'))
    end
end)

RegisterNetEvent('hud:loadStatus')
AddEventHandler('hud:loadStatus', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        if playerHudStatus[src] then
            TriggerClientEvent('hud:applyStatus', src, playerHudStatus[src])
            TriggerClientEvent('esx:showNotification', src, getTranslation('status_hud_restored'))
        else
            TriggerClientEvent('esx:showNotification', src, getTranslation('welcome_hud_initialized'))
        end
    end
end)

AddEventHandler('playerSpawned', function()
    local src = source
    TriggerClientEvent('hud:updatePlayerId', src, src)
end)

CreateThread(function()
    while true do
        Wait(5000)
        local xPlayers = ESX.GetPlayers()
        for _, playerId in ipairs(xPlayers) do
            TriggerClientEvent('hud:updatePlayerId', playerId, playerId)
        end
    end
end)

RegisterNetEvent('fekelele_hud:server:updateHunger')
AddEventHandler('fekelele_hud:server:updateHunger', function(hunger)
    local src = source
    TriggerClientEvent('fekelele_hud:updateHunger', src, hunger)
end)

RegisterNetEvent('fekelele_hud:server:updateThirst')
AddEventHandler('fekelele_hud:server:updateThirst', function(thirst)
    local src = source
    TriggerClientEvent('fekelele_hud:updateThirst', src, thirst)
end)

RegisterNetEvent('fekelele_hud:server:updateStress')
AddEventHandler('fekelele_hud:server:updateStress', function(stress)
    local src = source
    TriggerClientEvent('fekelele_hud:updateStress', src, stress)
end)

RegisterNetEvent('fekelele_hud:server:updateMicVolume')
AddEventHandler('fekelele_hud:server:updateMicVolume', function(volume)
    local src = source
    TriggerClientEvent('fekelele_hud:updateMicVolume', src, volume)
end)

RegisterNetEvent('fekelele_hud:savePlayerData')
AddEventHandler('fekelele_hud:savePlayerData', function(data)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        playerHudStatus[src] = {
            job = data.job,
            playerId = data.playerId,
            lastSeen = data.lastSeen,
            savedAt = os.time()
        }
        print(("^3[Fekelele HUD] ^7Dati salvati per giocatore %s (ID: %s)"):format(
            xPlayer.getName(), src
        ))
    end
end)

RegisterNetEvent('fekelele_hud:loadPlayerData')
AddEventHandler('fekelele_hud:loadPlayerData', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer and playerHudStatus[src] then
        local savedData = playerHudStatus[src]
        TriggerClientEvent('fekelele_hud:restoreData', src, savedData)
        print(("^2[Fekelele HUD] ^7Dati ripristinati per giocatore %s"):format(
            xPlayer.getName()
        ))
    end
end)

print("^2[Fekelele HUD] ^7Server script loaded successfully!")
