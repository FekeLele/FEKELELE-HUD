Config = {}

-- Configurazione generale / General configuration
Config.updateInterval = 200 -- Aggiornamento HUD ogni 200ms / HUD update every 200ms
Config.jobUpdateInterval = 2000 -- Aggiornamento job ogni 2 secondi / Job update every 2 seconds

-- Configurazione server / Server configuration
Config.slot = '4' -- Numero di slot del server / Server slot number
Config.serverLogo = 'https://i.postimg.cc/vZFtQVGS/logodever.png'

-- Configurazione HUD / HUD configuration
Config.showJob = true -- Mostra informazioni lavoro / Show job info
Config.showPlayerCount = true -- Mostra contatore giocatori / Show player count
Config.toggleCommand = 'togglehud' -- Comando per toggleare HUD / Command to toggle HUD
Config.toggleKey = 'F2' -- Tasto per toggleare HUD / Key to toggle HUD

-- Configurazione lingua / Language configuration
Config.language = 'it'

-- Traduzioni / Translations
Config.translations = {
    en = {
        jobs = 'Jobs',
        players = 'Players',
        id = 'ID',
        seatbelt = 'Seatbelt',
        job_label = 'Job',
        id_label = 'ID',
        players_label = 'Players',
        hud_enabled = 'HUD Enabled',
        hud_disabled = 'HUD Disabled',
        seatbelt_on = 'Seatbelt fastened',
        seatbelt_off = 'Seatbelt unfastened',
        ejected_from_vehicle = 'Ejected from vehicle! Use seatbelt!',
        seatbelt_saved = 'Seatbelt saved your life!',
        health_restored = 'Health restored',
        health_set = 'Health set to:',
        damage_received = 'You received',
        damage_points = 'damage',
        civilian = 'Civilian',
        police = 'Police',
        ambulance = 'EMS',
        mechanic = 'Mechanic',
        taxi = 'Taxi',
        cardealer = 'Car Dealer',
        realestateagent = 'Real Estate',
        unemployed = 'Unemployed',
        status_hud_restored = 'Status HUD restored!',
        welcome_hud_initialized = 'Welcome! HUD initialized.',
        status_hud_saved = 'Status HUD saved!'
    },
    it = {
        jobs = 'Lavori',
        players = 'Giocatori',
        id = 'ID',
        seatbelt = 'Cintura di sicurezza',
        job_label = 'Lavoro',
        id_label = 'ID',
        players_label = 'Giocatori',
        hud_enabled = 'HUD Attivato',
        hud_disabled = 'HUD Disattivato',
        seatbelt_on = 'Cintura allacciata',
        seatbelt_off = 'Cintura slacciata',
        seatbelt_blocked = 'Devi slacciare la cintura prima di uscire! Premi K',
        ejected_from_vehicle = 'Espulso dal veicolo! Usa la cintura!',
        seatbelt_saved = 'La cintura di sicurezza ti ha salvato!',
        health_restored = 'Salute ripristinata',
        health_set = 'Salute impostata a:',
        damage_received = 'Hai ricevuto',
        damage_points = 'danni',
        usage_sethealth = 'Uso: /sethealth <valore 0-200>',
        usage_damage = 'Uso: /damage <valore 1-100>',
        civilian = 'Civile',
        police = 'Polizia',
        ambulance = 'Medico',
        mechanic = 'Meccanico',
        taxi = 'Taxi',
        cardealer = 'Concessionario',
        realestateagent = 'Agente Immobiliare',
        unemployed = 'Disoccupato',
        status_hud_restored = 'Status HUD ripristinato!',
        welcome_hud_initialized = 'Benvenuto! HUD inizializzato.',
        status_hud_saved = 'Status HUD salvato!'
    }
}

-- Configurazione carburante / Fuel system configuration
Config.fuelSystem = 'auto' -- 'auto', 'ox_fuel', 'legacy_fuel', 'LegacyFuel', 'native'
Config.fuelUpdateInterval = 1000 -- Aggiornamento carburante ogni 1 secondo / Fuel update every 1 second

-- NOTA: Se hai problemi con il sistema carburante, prova: / NOTE: If you have problems with the fuel system, try:
-- 1. 'auto' - Rileva automaticamente il sistema carburante / Automatically detect fuel system
-- 2. 'native' - Usa solo il carburante nativo di GTA / Use only GTA native fuel
-- 3. 'ox_fuel' - Forza l'uso di ox_fuel / Force use of ox_fuel
-- 4. 'legacy_fuel' - Forza l'uso di legacy_fuel / Force use of legacy_fuel
-- 5. 'LegacyFuel' - Forza l'uso di LegacyFuel (maiuscolo) / Force use of LegacyFuel (uppercase)
-- 
-- Usa /fueltest in-game per testare i sistemi carburante disponibili / Use /fueltest in-game to test available fuel systems

-- Livelli di allarme carburante realistici (come nelle auto vere) / Realistic fuel warning levels (like real cars)
Config.fuelEmptyLevel = 5      -- Vuoto: sotto 5% (rosso intenso lampeggiante) / Empty: below 5% (flashing red)
Config.fuelCriticalLevel = 15  -- Critico: 5-15% (rosso lampeggiante - riserva) / Critical: 5-15% (flashing red - reserve)
Config.fuelWarningLevel = 30   -- Attenzione: 15-30% (arancione pulsante) / Warning: 15-30% (pulsing orange)
Config.fuelMediumLevel = 50    -- Medio: 30-50% (giallo fisso) / Medium: 30-50% (steady yellow)
-- Sopra 50% = normale (verde) / Above 50% = normal (green)

-- Configurazione barre di stato / Status bar configuration
Config.showHealth = true -- Mostra barra vita / Show health bar
Config.showArmor = true -- Mostra barra giubbotto / Show armor bar
Config.showHunger = true -- Mostra barra fame / Show hunger bar
Config.showThirst = true -- Mostra barra sete / Show thirst bar
Config.showStress = true -- Mostra barra stress / Show stress bar
Config.showMicrophone = true -- Mostra barra microfono / Show microphone bar
Config.showSpeedometer = true -- Mostra tachimetro quando in veicolo / Show speedometer when in vehicle

-- Configurazione esx_status / esx_status configuration
Config.useESXStatus = true -- Usa esx_status per fame, sete, stress / Use esx_status for hunger, thirst, stress
Config.statusUpdateInterval = 1000 -- Aggiornamento status ogni 1 secondo / Status update every 1 second

-- Nomi degli status in esx_status (puoi cambiarli se diversi nel tuo server) / esx_status names (change if different on your server)
Config.statusNames = {
    hunger = 'hunger',  -- Nome status fame / Hunger status name
    thirst = 'thirst',  -- Nome status sete / Thirst status name
    stress = 'stress'   -- Nome status stress / Stress status name
}

-- Valori default per gli status (se esx_status non è disponibile) / Default status values (if esx_status is not available)
Config.defaultStatusValues = {
    hunger = 100,
    thirst = 100,
    stress = 0
}

-- Funzione per ottenere traduzione / Function to get translation
function Config.getTranslation(key)
    local lang = Config.language
    if Config.translations[lang] and Config.translations[lang][key] then
        return Config.translations[lang][key]
    elseif Config.translations['en'] and Config.translations['en'][key] then
        return Config.translations['en'][key] -- Fallback inglese / English fallback
    else
        return key -- Fallback alla chiave originale / Fallback to original key
    end
end