local ESX = nil
local PlayerData = nil
local HudShown = true
local hasInitialized = false
local isPlayerLoaded = false
local lastJobUpdate = 0
local defaultStatusValues = {
    hunger = 1000000,
    thirst = 1000000,
    stress = 0
}
local statusValues = {
    hunger = defaultStatusValues.hunger,
    thirst = defaultStatusValues.thirst,
    stress = defaultStatusValues.stress
}
local lastSavedData = {}
local lastPlayerCount = 0
local lastMicLevel = 0
local lastMicStatus = 1
local lastKnownJob = nil
local jobUpdateTimer = 0
local lastPlayerCountUpdate = 0
local lastFuelUpdate = 0
local fuelLevel = 0
local fuelState = 'normal'
local currentPlayerId = nil
local hudVisible = true
local micVolume = 2
local seatbeltOn = false

CreateThread(function()
    while not ESX do
        ESX = exports["es_extended"]:getSharedObject()
        Wait(500)
    end
    while not ESX.IsPlayerLoaded() do 
        Wait(500) 
    end
    PlayerData = ESX.GetPlayerData()
    currentPlayerId = GetPlayerServerId(PlayerId())
    if HudShown then
        SendNUIMessage({ type = 'toggle', display = true })
        SendNUIMessage({ type = 'update_player_id', playerId = currentPlayerId })
        SendNUIMessage({ type = 'update_server_logo', logo = Config.serverLogo })
        SendNUIMessage({ 
            type = 'update_translations', 
            translations = {
                job_label = Config.getTranslation('job_label'),
                id_label = Config.getTranslation('id_label'),
                players_label = Config.getTranslation('players_label'),
                seatbelt = Config.getTranslation('seatbelt')
            }
        })
        initializeHUDComponents()
        if PlayerData.job then
            local jobName = PlayerData.job.name or 'unemployed'
            local jobLabel = Config.getTranslation(jobName)
            SendNUIMessage({ 
                type = 'update_job', 
                job = jobLabel,
                grade = PlayerData.job.grade_label
            })
        end
    end
end)

RegisterNetEvent('esx_status:onTick', function(data)
    for _, v in pairs(data) do
        if v.name == Config.statusNames.hunger then 
            statusValues.hunger = math.floor(v.percent)
        elseif v.name == Config.statusNames.thirst then 
            statusValues.thirst = math.floor(v.percent)
        elseif v.name == Config.statusNames.stress then 
            statusValues.stress = math.floor(v.percent)
        end
    end
end)

RegisterNetEvent('esx_status:update', function(status, value)
    if status == Config.statusNames.hunger then 
        statusValues.hunger = math.floor(value)
    elseif status == Config.statusNames.thirst then 
        statusValues.thirst = math.floor(value)
    elseif status == Config.statusNames.stress then 
        statusValues.stress = math.floor(value)
        print("^3[STRESS DEBUG]^7 update - Stress aggiornato a: " .. statusValues.stress)
    end
end)

RegisterNetEvent('esx_status:set', function(status, value)
    if status == Config.statusNames.hunger then 
        statusValues.hunger = math.floor(value / 10000)
    elseif status == Config.statusNames.thirst then 
        statusValues.thirst = math.floor(value / 10000)
    elseif status == Config.statusNames.stress then 
        statusValues.stress = math.floor(value / 10000)
        print("^3[STRESS DEBUG]^7 set - Stress impostato a: " .. statusValues.stress .. "% (valore raw: " .. value .. ")")
    end
end)

function getFuelLevel(vehicle)
    if not vehicle or vehicle == 0 then
        return 0
    end
    if Config.fuelSystem == 'auto' then
        local fuel = nil
        if GetResourceState('ox_fuel') == 'started' then
            local success, result = pcall(function()
                local fuelLevel = exports.ox_fuel:GetFuel(vehicle)
                if fuelLevel then return fuelLevel end
                return exports.ox_fuel:GetVehicleFuelLevel(vehicle)
            end)
            if success and result and result > 0 then
                fuel = result
            end
        end
        if not fuel and GetResourceState('legacy_fuel') == 'started' then
            local success, result = pcall(function()
                return exports.legacy_fuel:GetFuel(vehicle)
            end)
            if success and result and result > 0 then
                fuel = result
            end
        end
        if not fuel and GetResourceState('LegacyFuel') == 'started' then
            local success, result = pcall(function()
                return exports.LegacyFuel:GetFuel(vehicle)
            end)
            if success and result and result > 0 then
                fuel = result
            end
        end
        if not fuel then
            fuel = GetVehicleFuelLevel(vehicle)
        end
        return fuel
    elseif Config.fuelSystem == 'ox_fuel' then
        local success, result = pcall(function()
            local fuelLevel = exports.ox_fuel:GetFuel(vehicle)
            if fuelLevel then return fuelLevel end
            return exports.ox_fuel:GetVehicleFuelLevel(vehicle)
        end)
        if success and result then
            return result
        else
            return GetVehicleFuelLevel(vehicle)
        end
    elseif Config.fuelSystem == 'legacy_fuel' then
        local success, result = pcall(function()
            return exports.legacy_fuel:GetFuel(vehicle)
        end)
        if success and result then
            return result
        else
            return GetVehicleFuelLevel(vehicle)
        end
    elseif Config.fuelSystem == 'LegacyFuel' then
        local success, result = pcall(function()
            return exports.LegacyFuel:GetFuel(vehicle)
        end)
        if success and result then
            return result
        else
            return GetVehicleFuelLevel(vehicle)
        end
    else
        return GetVehicleFuelLevel(vehicle)
    end
end

function getFuelState(fuelLevel)
    if fuelLevel <= Config.fuelEmptyLevel then
        return 'empty'
    elseif fuelLevel <= Config.fuelCriticalLevel then
        return 'critical'
    elseif fuelLevel <= Config.fuelWarningLevel then
        return 'warning'
    elseif fuelLevel <= Config.fuelMediumLevel then
        return 'medium'
    else
        return 'normal'
    end
end

CreateThread(function()
    while true do
        Wait(Config.updateInterval)
        if not HudShown then
            goto continue
        end
        local ped = PlayerPedId()
        local health = math.floor(GetEntityHealth(ped) - 100)
        local armor = GetPedArmour(ped)
        local veh = GetVehiclePedIsIn(ped, false)
        local isDriver = veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
        local speed, rpm, fuel = 0, 0, 0
        if isDriver then
            speed = math.floor(GetEntitySpeed(veh) * 3.6)
            rpm = math.floor(GetVehicleCurrentRpm(veh) * 8000)
            if GetGameTimer() - lastFuelUpdate > Config.fuelUpdateInterval then
                local success, result = pcall(function()
                    return getFuelLevel(veh)
                end)
                if success and result then
                    fuelLevel = result
                    fuelState = getFuelState(fuelLevel)
                else
                    fuelLevel = GetVehicleFuelLevel(veh)
                    fuelState = getFuelState(fuelLevel)
                end
                lastFuelUpdate = GetGameTimer()
            end
            fuel = fuelLevel
        end
        local hudData = {
            type = 'update_hud',
            playerId = currentPlayerId or GetPlayerServerId(PlayerId())
        }
        if Config.showHunger then
            hudData.cibo = statusValues.hunger
        end
        if Config.showThirst then
            hudData.sete = statusValues.thirst
        end
        if Config.showStress then
            hudData.stress = statusValues.stress
        end
        if Config.showHealth then
            hudData.vita = health
        end
        if Config.showArmor then
            hudData.giubbotto = armor
        end
        if Config.showMicrophone then
            hudData.volume = NetworkIsPlayerTalking(PlayerId()) and micVolume or 0
        end
        if Config.showSpeedometer and isDriver then
            hudData.speed = speed
            hudData.fuel = fuel
            hudData.rpm = rpm
            hudData.hasVehicle = true
            hudData.fuelState = fuelState
            hudData.seatbelt = seatbeltOn
        else
            hudData.hasVehicle = false
        end
        SendNUIMessage(hudData)
        ::continue::
    end
end)

function updateJobLabel()
    if not Config.showJob then
        return
    end
    if PlayerData and PlayerData.job then
        local jobName = PlayerData.job.name or 'unemployed'
        local jobLabel = Config.getTranslation(jobName)
        SendNUIMessage({ 
            type = 'update_job', 
            jobName = jobLabel,
            grade = PlayerData.job.grade_label
        })
    else
        local defaultJobLabel = Config.getTranslation('unemployed')
        SendNUIMessage({ 
            type = 'update_job', 
            jobName = defaultJobLabel
        })
    end
end

RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
    updateJobLabel()
end)

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    currentPlayerId = GetPlayerServerId(PlayerId())
    SendNUIMessage({ type = 'update_player_id', playerId = currentPlayerId })
    updateJobLabel()
end)

CreateThread(function()
    while true do
        Wait(Config.jobUpdateInterval)
        updateJobLabel()
    end
end)

CreateThread(function()
    while true do
        Wait(Config.jobUpdateInterval)
        if Config.showPlayerCount then
            local currentPlayers = #GetActivePlayers()
            local maxPlayers = tonumber(Config.slot) or 64
            SendNUIMessage({
                type = 'update_player_count',
                current = currentPlayers,
                max = maxPlayers
            })
        end
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        DisplayRadar(IsPedInAnyVehicle(PlayerPedId(), false))
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        -- Nascondi solo i componenti HUD necessari, non tutti
        -- Hide only necessary HUD components, not all
        HideHudComponentThisFrame(1)  -- Wanted Level
        HideHudComponentThisFrame(2)  -- Weapon Icon
        HideHudComponentThisFrame(3)  -- Cash
        -- NON nascondere il componente 4 (Vehicle Health) perché interferisce con l'uscita dal veicolo
        HideHudComponentThisFrame(6)  -- Vehicle Name
        HideHudComponentThisFrame(7)  -- Area Name
        HideHudComponentThisFrame(8)  -- Vehicle Class
        HideHudComponentThisFrame(9)  -- Street Name
        HideHudComponentThisFrame(13) -- Cash Change
        HideHudComponentThisFrame(11) -- Floating Help Text
        HideHudComponentThisFrame(12) -- Help Text
        HideHudComponentThisFrame(15) -- Subtitle Text
        HideHudComponentThisFrame(18) -- Game Stream
        HideHudComponentThisFrame(19) -- Weapon Wheel
        HideHudComponentThisFrame(20) -- Weapon Wheel Stats
        HideHudComponentThisFrame(22) -- Saving Game
        
        if IsHelpMessageOnScreen() then
            ClearAllHelpMessages()
        end
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)
        if IsPedInAnyVehicle(ped, false) then
            SetPlayerHealthRechargeLimit(PlayerId(), 0.25)
        end
    end
end)

TriggerEvent("pma-voice:settingsCallback", function(settings)
    voiceModes = settings.voiceModes or {}
end)

local function updateMicNUI()
    if not Config.showMicrophone then
        return
    end
    local isTalking = NetworkIsPlayerTalking(PlayerId())
    SendNUIMessage({
        type = 'update_mic_volume',
        volume = micVolume,
        isTalking = isTalking
    })
end

local function onMicChange(mode)
    micVolume = mode
    updateMicNUI()
end

RegisterNetEvent('pma-voice:setTalkingMode', onMicChange)
RegisterNetEvent('pma-voice:modeChanged', onMicChange)
AddEventHandler('pma-voice:setTalkingMode', onMicChange)
AddEventHandler('pma-voice:modeChanged', onMicChange)

CreateThread(function()
    Wait(2000)
    local ok, mode = pcall(function() return exports['pma-voice']:getProximityMode() end)
    micVolume = (ok and mode) or 2
end)

CreateThread(function()
    while true do
        Wait(100)
        updateMicNUI()
    end
end)

RegisterKeyMapping('toggleSeatbelt', 'Toggle Cintura', 'keyboard', 'K')
RegisterCommand('toggleSeatbelt', function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
        seatbeltOn = not seatbeltOn
        if seatbeltOn then
            ESX.ShowNotification(Config.getTranslation('seatbelt_on'), 'success')
            print("^2[CINTURA]^7 Cintura ATTIVATA - Il giocatore non sarà espulso dal veicolo")
        else
            ESX.ShowNotification(Config.getTranslation('seatbelt_off'), 'error')
            print("^1[CINTURA]^7 Cintura DISATTIVATA - Il giocatore sarà espulso in caso di incidente")
        end
        SendNUIMessage({
            type = 'update_seatbelt',
            seatbelt = seatbeltOn
        })
    end
end)

CreateThread(function()
    local wasInVehicle = false
    while true do
        Wait(100)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local isInVehicle = veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
        
        -- Reset cintura solo quando si esce dal veicolo (ma ora il giocatore non può uscire con la cintura)
        if wasInVehicle and not isInVehicle then
            -- Se il giocatore è riuscito a uscire dal veicolo, resetta la cintura
            if seatbeltOn then
                seatbeltOn = false
                SendNUIMessage({
                    type = 'update_seatbelt',
                    seatbelt = false
                })
                ESX.ShowNotification('Cintura di sicurezza slacciata automaticamente', 'info')
            end
        end
        
        wasInVehicle = isInVehicle
    end
end)

CreateThread(function()
    local lastVelocity = {x = 0, y = 0, z = 0}
    local wasInVehicle = false
    
    while true do
        Wait(50)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local isDriver = veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
        
        if isDriver then
            local velocity = GetEntityVelocity(veh)
            local currentSpeed = math.sqrt(velocity.x^2 + velocity.y^2 + velocity.z^2)
            local lastSpeed = math.sqrt(lastVelocity.x^2 + lastVelocity.y^2 + lastVelocity.z^2)
            local speedDifference = lastSpeed - currentSpeed
            
            -- Solo se c'è un impatto significativo
            if speedDifference > 15 and wasInVehicle then
                if not seatbeltOn then
                    -- SENZA CINTURA: Espulsione dal veicolo
                    local ejectForce = math.min(speedDifference / 15, 2.0)
                    SetEntityHealth(ped, GetEntityHealth(ped) - math.floor(speedDifference * 3))
                    SetPedToRagdoll(ped, 5000, 5000, 0, 0, 0, 0)
                    Wait(100)
                    SetEntityCoords(ped, 
                        GetEntityCoords(ped).x + math.random(-3, 3), 
                        GetEntityCoords(ped).y + math.random(-3, 3), 
                        GetEntityCoords(ped).z + 1
                    )
                    SetEntityVelocity(ped, 
                        velocity.x * ejectForce * 0.5, 
                        velocity.y * ejectForce * 0.5, 
                        math.abs(velocity.z) * ejectForce + 5
                    )
                    ESX.ShowNotification(Config.getTranslation('ejected_from_vehicle'), 'error')
                    PlaySoundFrontend(-1, "LOSER", "HUD_AWARDS", 1)
                    ShakeGameplayCam('LARGE_EXPLOSION_SHAKE', 1.0)
                else
                    -- CON CINTURA: Rimane nel veicolo ma subisce danni ridotti
                    SetEntityHealth(ped, GetEntityHealth(ped) - math.floor(speedDifference * 1))
                    SetPedToRagdoll(ped, 1000, 1000, 0, 0, 0, 0)
                    ESX.ShowNotification(Config.getTranslation('seatbelt_saved'), 'success')
                    PlaySoundFrontend(-1, "CHECKPOINT_PERFECT", "HUD_MINI_GAME_SOUNDSET", 1)
                    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.5)
                end
                lastVelocity = {x = 0, y = 0, z = 0}
            else
                lastVelocity = velocity
            end
            wasInVehicle = true
        else
            wasInVehicle = false
            lastVelocity = {x = 0, y = 0, z = 0}
        end
    end
end)

function initializeHUDComponents()
    if not Config.showJob then
        SendNUIMessage({ type = 'hide_component', component = 'job' })
    end
    if not Config.showPlayerCount then
        SendNUIMessage({ type = 'hide_component', component = 'playerCount' })
    end
    if not Config.showHealth then
        SendNUIMessage({ type = 'hide_component', component = 'health' })
    end
    if not Config.showArmor then
        SendNUIMessage({ type = 'hide_component', component = 'armor' })
    end
    if not Config.showHunger then
        SendNUIMessage({ type = 'hide_component', component = 'hunger' })
    end
    if not Config.showThirst then
        SendNUIMessage({ type = 'hide_component', component = 'thirst' })
    end
    if not Config.showStress then
        SendNUIMessage({ type = 'hide_component', component = 'stress' })
    end
    if not Config.showMicrophone then
        SendNUIMessage({ type = 'hide_component', component = 'microphone' })
    end
    if not Config.showSpeedometer then
        SendNUIMessage({ type = 'hide_component', component = 'speedometer' })
    end
end

function toggleHUD()
    HudShown = not HudShown
    SendNUIMessage({ type = 'toggle', display = HudShown })
    if HudShown then
        ESX.ShowNotification(Config.getTranslation('hud_enabled'), 'success')
    else
       ESX.ShowNotification(Config.getTranslation('hud_disabled'), 'info')
    end
end

RegisterCommand('togglehud', function()
    toggleHUD()
end)

RegisterKeyMapping('seatbelt', 'Toggle Seatbelt', 'keyboard', 'K')

-- Thread per bloccare l'uscita dal veicolo quando la cintura è attivata
CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        
        -- Se il giocatore è in un veicolo e ha la cintura attivata
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped and seatbeltOn then
            -- Blocca il tasto F (uscita dal veicolo) quando la cintura è attivata
            if IsControlJustPressed(0, 75) then -- F key
                ESX.ShowNotification(Config.getTranslation('seatbelt_blocked'), 'error')
                -- Impedisce l'uscita dal veicolo
                DisableControlAction(0, 75, true) -- F key
            end
            
            -- Disabilita continuamente il controllo di uscita
            DisableControlAction(0, 75, true) -- F key
        end
    end
end)

