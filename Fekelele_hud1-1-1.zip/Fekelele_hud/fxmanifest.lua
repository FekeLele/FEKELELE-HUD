fx_version 'cerulean'
game 'gta5'

author 'Fekelele'
description 'HUD Realistico per FiveM'
version '1.0.0'


shared_scripts {
    'config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}


ui_page 'html/index.html'


files {
    'html/index.html',
    'html/styele.css',
    'html/script.js'
}

dependencies {
    'es_extended',
    'esx_status',
    'pma-voice'
}
