const playerIdEl = document.getElementById('playerId');
const jobInfoEl = document.getElementById('jobInfo');
const playerCountEl = document.getElementById('playerCount');

const hudBoxes = {
  cibo: document.querySelector('#cibo .fill-color'),
  sete: document.querySelector('#sete .fill-color'),
  stress: document.querySelector('#stress .fill-color'),
  vita: document.querySelector('#vita .fill-color'),
  giubbo: document.querySelector('#giubbo .fill-color'),
  microfono: document.querySelector('#microfono .fill-color'),
};

const statusBoxes = {
  microfono: document.getElementById('microfono'),
  vita: document.getElementById('vita'),
  cibo: document.getElementById('cibo'),
  sete: document.getElementById('sete'),
  stress: document.getElementById('stress'),
  giubbo: document.getElementById('giubbo'),
};

const speedNeedle = document.getElementById('speedNeedle');
const rpmNeedle = document.getElementById('rpmNeedle');
const rpmDigital = document.getElementById('rpmDigital');
const fuelBarFill = document.getElementById('fuelBarFill');
const fuelBarText = document.getElementById('fuelBarText');
const seatbeltValue = document.getElementById('seatbeltValue');

function toggleVehicleHud(show) {
  const speedContainer = document.querySelector('.speed-container');
  if (speedContainer) speedContainer.style.display = show ? 'block' : 'none';
  const rpmContainer = document.querySelector('.rpm-circle-container');
  if (rpmContainer) rpmContainer.style.display = show ? 'flex' : 'none';
  const fuelBarContainer = document.querySelector('.fuel-bar-container');
  if (fuelBarContainer) fuelBarContainer.style.display = show ? 'flex' : 'none';
}

function updateFill(id, percent, shouldShow = true) {
  const fillEl = hudBoxes[id];
  const boxEl = statusBoxes[id];
  if (!fillEl || !boxEl) return;
  if (!shouldShow) {
    boxEl.style.display = 'none';
    return;
  }
  percent = Math.max(0, Math.min(100, percent));
  if (id === 'stress' || id === 'giubbo') {
    boxEl.style.display = percent <= 0 ? 'none' : 'flex';
    if (percent <= 0) return;
  } else {
    boxEl.style.display = 'flex';
  }
  if (id === 'vita') {
    fillEl.style.height = `${percent}%`;
    fillEl.style.opacity = 0.65;
    fillEl.style.background = percent > 66
      ? 'linear-gradient(180deg, #27ae60, #2ecc71)'
      : percent > 33
      ? 'linear-gradient(180deg, #f1c40f, #f39c12)'
      : 'linear-gradient(180deg, #e74c3c, #c0392b)';
  } else {
    fillEl.style.height = percent <= 0 ? '2px' : `${percent}%`;
    fillEl.style.opacity = percent <= 0 ? '0.3' : '0.65';
  }
  fillEl.style.bottom = '0';
  const valueEl = boxEl.querySelector('.status-value');
  if (valueEl) {
    let displayPercent = percent;
    // Se cibo o sete sono al massimo (99), mostra 100%
    if ((id === 'cibo' || id === 'sete') && percent >= 99) {
      displayPercent = 100;
    }
    valueEl.textContent = `${displayPercent}%`;
  }
}
function updateMicVisual(volume, isTalking) {
  const boxEl = statusBoxes['microfono'];
  const fillEl = hudBoxes['microfono'];
  if (!fillEl || !boxEl) return;
  const micIcon = boxEl.querySelector('.status-icon i');
  let rangeMeters = 0;
  let percent = 0;
  let color = '#00CFFF';
  if (isTalking && volume > 0) {
    switch (volume) {
      case 1: rangeMeters = 10; percent = 33; color = '#55c3ff'; break;
      case 2: rangeMeters = 50; percent = 66; color = '#00CFFF'; break;
      case 3: rangeMeters = 100; percent = 100; color = '#0077AA'; break;
      default: rangeMeters = 0; percent = 0; color = '#ffffff';
    }
  } else {
    rangeMeters = 0;
    percent = 0;
    color = '#ffffff';
  }
  fillEl.style.height = `${percent}%`;
  fillEl.style.opacity = isTalking ? '0.85' : '0.4';
  fillEl.style.background = color;
  const valueEl = boxEl.querySelector('.status-value');
  if (valueEl) valueEl.textContent = `${rangeMeters}m`;
  if (micIcon) {
    micIcon.style.color = isTalking ? color : '#999';
  }
}

function updateRpm(rpm) {
  if (!rpmNeedle || !rpmDigital) return;
  rpmDigital.textContent = rpm.toString().padStart(4, '0');
  const maxRpm = 8000;
  const rpmPercent = Math.min(rpm / maxRpm, 1);
  const rpmRotation = (rpmPercent * 90) - 90;
  rpmNeedle.style.transform = `rotate(${rpmRotation}deg)`;
}

function updateSpeedAndFuel(speed, fuel, rpm = 0, show = true, fuelState = 'normal') {
  if (speedNeedle) {
    const maxSpeed = 280;
    const speedPercent = Math.min(speed / maxSpeed, 1);
    const speedRotation = (speedPercent * 180) - 90;
    speedNeedle.style.transform = `rotate(${speedRotation}deg)`;
  }
  if (fuelBarFill && fuelBarText) {
    const fuelPercent = Math.max(0, Math.min(100, fuel));
    fuelBarFill.style.width = `${fuelPercent}%`;
    fuelBarText.textContent = `${Math.round(fuelPercent)}%`;
    fuelBarFill.classList.remove('fuel-low', 'fuel-critical', 'fuel-warning', 'fuel-empty');
    let barColor;
    let shouldBlink = false;
    if (fuelState) {
      switch (fuelState) {
        case 'empty':
          barColor = '#ff0000';
          shouldBlink = true;
          fuelBarFill.classList.add('fuel-empty');
          break;
        case 'critical':
          barColor = '#ff3300';
          shouldBlink = true;
          fuelBarFill.classList.add('fuel-critical');
          break;
        case 'warning':
          barColor = '#ff6600';
          fuelBarFill.classList.add('fuel-warning');
          break;
        case 'medium':
          barColor = '#ffaa00';
          break;
        case 'normal':
        default:
          barColor = '#00ff00';
          break;
      }
    } else {
      if (fuelPercent <= 15) {
        barColor = '#ff0000';
        fuelBarFill.classList.add('fuel-low');
      } else if (fuelPercent <= 30) {
        barColor = '#ff6600';
      } else if (fuelPercent <= 60) {
        barColor = '#ffaa00';
      } else {
        barColor = '#00ff00';
      }
    }
    fuelBarFill.style.background = barColor;
    if (shouldBlink) {
      fuelBarFill.style.animation = 'blink 0.5s infinite';
    } else {
      fuelBarFill.style.animation = 'none';
    }
  }
  updateRpm(rpm);
}

function toggleHUD(show) {
  const hudContainer = document.querySelector('.hud-container');
  const topRightInfo = document.querySelector('.top-right-info');
  const hudBottomRight = document.querySelector('.hud-bottom-right');
  if (hudContainer) hudContainer.style.display = show ? 'block' : 'none';
  if (topRightInfo) {
    topRightInfo.style.display = show ? 'flex' : 'none';
    topRightInfo.style.visibility = show ? 'visible' : 'hidden';
  }
  if (hudBottomRight) {
    hudBottomRight.style.display = show ? 'flex' : 'none';
    hudBottomRight.style.visibility = show ? 'visible' : 'hidden';
  }
}

function updateJobInfo(jobName) {
  if (jobInfoEl) {
    jobInfoEl.textContent = jobName || 'Civilian';
  }
}

function updatePlayerCount(current, max) {
  if (playerCountEl) {
    playerCountEl.textContent = `${current}/${max}`;
  }
}

function updatePlayerId(id) {
  if (playerIdEl) {
    playerIdEl.textContent = id !== undefined ? id : '--';
  }
}

function updateSeatbelt(isOn) {
  if (seatbeltValue) {
    seatbeltValue.textContent = isOn ? 'ON' : 'OFF';
    seatbeltValue.style.color = isOn ? '#00ff00' : '#ff0000';
  }
}

window.addEventListener('message', (event) => {
  const data = event.data;
  if (!data) return;
  switch (data.type) {
    case 'update_hud':
      if (data.hasOwnProperty('cibo')) updateFill('cibo', data.cibo || 0, true);
      if (data.hasOwnProperty('sete')) updateFill('sete', data.sete || 0, true);
      if (data.hasOwnProperty('stress')) updateFill('stress', data.stress || 0, true);
      if (data.hasOwnProperty('vita')) updateFill('vita', data.vita || 0, true);
      if (data.hasOwnProperty('giubbotto')) updateFill('giubbo', data.giubbotto || 0, true);
      if (data.hasOwnProperty('speed') || data.hasOwnProperty('fuel')) {
        updateSpeedAndFuel(
          data.speed || 0, 
          data.fuel || 0, 
          data.rpm || 0, 
          data.hasVehicle,
          data.fuelState
        );
      }
      if (data.hasOwnProperty('seatbelt')) {
        updateSeatbelt(data.seatbelt);
      }
      if (data.hasOwnProperty('playerId')) updatePlayerId(data.playerId);
      if (data.hasOwnProperty('hasVehicle')) toggleVehicleHud(data.hasVehicle);
      break;
    case 'update_mic_volume':
      updateMicVisual(data.volume, data.isTalking);
      break;
    case 'toggle':
      toggleHUD(data.display);
      break;
    case 'update_player_id':
      updatePlayerId(data.playerId);
      break;
    case 'update_job':
      updateJobInfo(data.jobName);
      break;
    case 'update_player_count':
      updatePlayerCount(data.current, data.max);
      break;
    case 'update_server_logo':
      const serverLogo = document.getElementById('serverLogo');
      if (serverLogo && data.logo) {
        serverLogo.src = data.logo;
        serverLogo.style.display = 'block';
      }
      break;
    case 'update_translations':
      if (data.translations) {
        const jobPanel = document.querySelector('.info-panel strong');
        if (jobPanel && jobPanel.textContent.includes('Job')) {
          jobPanel.textContent = data.translations.job_label + ':';
        }
        const panels = document.querySelectorAll('.info-panel strong');
        panels.forEach(panel => {
          if (panel.textContent.includes('ID')) {
            panel.textContent = data.translations.id_label + ':';
          } else if (panel.textContent.includes('Players') || panel.textContent.includes('Giocatori')) {
            panel.textContent = data.translations.players_label + ':';
          }
        });
        const seatbeltLabel = document.querySelector('.info-label');
        if (seatbeltLabel && data.translations.seatbelt) {
          seatbeltLabel.textContent = data.translations.seatbelt.toUpperCase();
        }
      }
      break;
    case 'debug':
      console.log('Debug richiesto:', data.message);
      debugHUD();
      break;
    case 'hide_component':
      if (data.component) {
        hideComponent(data.component);
      }
      break;
    case 'show_component':
      if (data.component) {
        showComponent(data.component);
      }
      break;
  }
});

function hideComponent(componentName) {
  switch (componentName) {
    case 'job':
      if (jobInfoEl) jobInfoEl.style.display = 'none';
      break;
    case 'playerCount':
      if (playerCountEl) playerCountEl.style.display = 'none';
      break;
    case 'playerId':
      if (playerIdEl) playerIdEl.style.display = 'none';
      break;
    case 'hunger':
      if (statusBoxes['cibo']) statusBoxes['cibo'].style.display = 'none';
      break;
    case 'thirst':
      if (statusBoxes['sete']) statusBoxes['sete'].style.display = 'none';
      break;
    case 'stress':
      if (statusBoxes['stress']) statusBoxes['stress'].style.display = 'none';
      break;
    case 'health':
      if (statusBoxes['vita']) statusBoxes['vita'].style.display = 'none';
      break;
    case 'armor':
      if (statusBoxes['giubbo']) statusBoxes['giubbo'].style.display = 'none';
      break;
    case 'microphone':
      if (statusBoxes['microfono']) statusBoxes['microfono'].style.display = 'none';
      break;
    case 'speedometer':
      toggleVehicleHud(false);
      break;
  }
}

function showComponent(componentName) {
  switch (componentName) {
    case 'job':
      if (jobInfoEl) jobInfoEl.style.display = 'block';
      break;
    case 'playerCount':
      if (playerCountEl) playerCountEl.style.display = 'block';
      break;
    case 'playerId':
      if (playerIdEl) playerIdEl.style.display = 'block';
      break;
    case 'hunger':
      if (statusBoxes['cibo']) statusBoxes['cibo'].style.display = 'flex';
      break;
    case 'thirst':
      if (statusBoxes['sete']) statusBoxes['sete'].style.display = 'flex';
      break;
    case 'stress':
      if (statusBoxes['stress']) statusBoxes['stress'].style.display = 'flex';
      break;
    case 'health':
      if (statusBoxes['vita']) statusBoxes['vita'].style.display = 'flex';
      break;
    case 'armor':
      if (statusBoxes['giubbo']) statusBoxes['giubbo'].style.display = 'flex';
      break;
    case 'microphone':
      if (statusBoxes['microfono']) statusBoxes['microfono'].style.display = 'flex';
      break;
    case 'speedometer':
      break;
  }
}

function debugHUD() {
  console.log('=== DEBUG HUD ===');
  console.log('Player ID Element:', playerIdEl);
  console.log('Job Info Element:', jobInfoEl);
  console.log('Player Count Element:', playerCountEl);
  console.log('HUD Boxes:', hudBoxes);
  console.log('Status Boxes:', statusBoxes);
  console.log('Speed Needle:', speedNeedle);
  console.log('RPM Needle:', rpmNeedle);
  console.log('Fuel Bar Fill:', fuelBarFill);
  const missing = [];
  if (!playerIdEl) missing.push('playerId');
  if (!jobInfoEl) missing.push('jobInfo');
  if (!playerCountEl) missing.push('playerCount');
  if (!speedNeedle) missing.push('speedNeedle');
  if (!rpmNeedle) missing.push('rpmNeedle');
  if (!fuelBarFill) missing.push('fuelBarFill');
  Object.keys(hudBoxes).forEach(key => {
    if (!hudBoxes[key]) missing.push(`hudBox-${key}`);
  });
  Object.keys(statusBoxes).forEach(key => {
    if (!statusBoxes[key]) missing.push(`statusBox-${key}`);
  });
  if (missing.length > 0) {
    console.warn('Elementi mancanti:', missing);
  } else {
    console.log('✅ Tutti gli elementi HUD sono presenti!');
  }
}

updateMicVisual(0, false);
updateSpeedAndFuel(0, 0, 0, false);
toggleHUD(true);
updatePlayerId(1);
updateJobInfo('Civilian');
updatePlayerCount(1, 64);
updateFill('vita', 100);
updateFill('cibo', 100);
updateFill('sete', 100);
updateFill('stress', 0);
updateFill('giubbo', 0);
toggleVehicleHud(false);

if (speedNeedle) {
    speedNeedle.style.transform = 'rotate(-90deg)';
}
if (rpmNeedle) {
    rpmNeedle.style.transform = 'rotate(-90deg)';
}

updateSeatbelt(false);
